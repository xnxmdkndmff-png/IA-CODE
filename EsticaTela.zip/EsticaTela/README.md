# Estica Tela

App Android que muda a resolução/proporção da tela (o mesmo efeito do comando `wm size`)
para deixar os jogos "esticados". Tem temporizador de segurança de 15 s que restaura a tela.

## 1. Preparar o celular (uma vez)
1. Instale o app **Shizuku** (Play Store ou GitHub RikkaApps/Shizuku).
2. Ative as Opções do desenvolvedor e a **Depuração sem fio**.
3. No Shizuku, toque em "Iniciar via depuração sem fio" e siga o pareamento.
   (Depois de reiniciar o celular, é preciso iniciar o Shizuku de novo.)

## 2. Compilar
1. Abra a pasta `EsticaTela` no **Android Studio** (Koala ou mais novo) e espere o Gradle sincronizar.
2. Conecte o celular (ou use Build > Build APK) e rode o módulo `app`.

## 3. Usar
1. Abra o Estica Tela e conceda a permissão do Shizuku.
2. Escolha uma predefinição (ou digite largura × altura) e toque em **Manter essa tela** em até 15 s.
3. Abra o jogo.
4. Para voltar ao normal: **Restaurar tela original**.

## Se algo der errado
No computador, com o celular conectado por ADB: `adb shell wm size reset`

## Sem computador: gerar o APK pelo GitHub (tudo pelo navegador do celular)
1. Crie uma conta e um repositório no github.com.
2. Suba todos os arquivos deste projeto, mantendo as pastas (inclusive `.github/workflows/build.yml`).
3. Abra a aba **Actions**, escolha **Gerar APK** e toque em **Run workflow**.
4. Quando terminar (uns 3 a 5 minutos), abra a execução e baixe **EsticaTela-apk** na seção Artifacts.
5. Descompacte, instale o `app-debug.apk` (permita "instalar apps desconhecidos") e siga os passos do Shizuku acima.
