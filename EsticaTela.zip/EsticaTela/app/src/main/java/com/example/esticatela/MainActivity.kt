package com.example.esticatela

import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.CountDownTimer
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private enum class State { OFF, NEED, READY }

    private lateinit var status: TextView
    private lateinit var current: TextView
    private lateinit var grant: Button
    private lateinit var controls: LinearLayout
    private lateinit var presets: LinearLayout
    private lateinit var confirmBox: LinearLayout
    private lateinit var confirmText: TextView
    private lateinit var inputW: EditText
    private lateinit var inputH: EditText

    private var timer: CountDownTimer? = null
    private var physW = 0
    private var physH = 0

    private val onBinder = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }
    private val onDead = Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }
    private val onPerm =
        Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPerm)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        timer?.cancel()
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeBinderDeadListener(onDead)
        Shizuku.removeRequestPermissionResultListener(onPerm)
        super.onDestroy()
    }

    // ---------------------------------------------------------------- interface

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun label(t: String, size: Float, top: Int = 0) = TextView(this).apply {
        text = t
        textSize = size
        setPadding(0, dp(top), 0, 0)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(36), dp(20), dp(24))
        }

        root.addView(label("Estica Tela", 26f))

        status = label("", 15f, 12)
        root.addView(status)

        grant = btn("Conceder permissão do Shizuku") { askPermission() }
        root.addView(grant)

        current = label("", 14f, 12)
        root.addView(current)

        controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        confirmBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(0, dp(12), 0, dp(12))
        }
        confirmText = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.YELLOW)
        }
        confirmBox.addView(confirmText)
        confirmBox.addView(btn("Manter essa tela") { keep() })
        controls.addView(confirmBox)

        controls.addView(label("Predefinições", 18f, 12))
        presets = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        controls.addView(presets)

        controls.addView(label("Personalizada (largura × altura, em pixels)", 18f, 20))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        inputW = EditText(this).apply {
            hint = "720"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        inputH = EditText(this).apply {
            hint = "960"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        row.addView(inputW, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(TextView(this).apply { text = "  ×  " })
        row.addView(inputH, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        controls.addView(row)
        controls.addView(btn("Aplicar personalizada") { applyCustom() })

        controls.addView(btn("Restaurar tela original") { reset() })

        controls.addView(
            label(
                "Dica: depois de aplicar, toque em \"Manter essa tela\" ANTES de abrir o jogo. " +
                    "Se você não confirmar em 15 segundos, a tela volta ao normal sozinha.",
                13f, 20
            )
        )
        root.addView(controls)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun buildPresets() {
        presets.removeAllViews()
        if (physW <= 0) return
        val w = physW
        fun even(x: Double) = (x.toInt() / 2) * 2

        val list = listOf(
            Triple("4:3 (mais esticado)", w, even(w * 4 / 3.0)),
            Triple("3:2", w, even(w * 3 / 2.0)),
            Triple("16:9 (esticado leve)", w, even(w * 16 / 9.0)),
            Triple("4:3 leve (75% da resolução)", even(w * 0.75), even(w * 0.75 * 4 / 3.0))
        )
        for ((name, pw, ph) in list) {
            presets.addView(btn("$name  —  ${pw}x$ph") { applySize(pw, ph) })
        }
    }

    // ---------------------------------------------------------------- estado do Shizuku

    private fun state(): State = try {
        when {
            !Shizuku.pingBinder() -> State.OFF
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> State.READY
            else -> State.NEED
        }
    } catch (e: Throwable) {
        State.OFF
    }

    private fun refresh() {
        when (state()) {
            State.OFF -> {
                status.text = "O Shizuku não está rodando. Abra o app Shizuku e inicie o serviço " +
                    "(depuração sem fio), depois volte aqui."
                grant.visibility = View.GONE
                controls.visibility = View.GONE
            }
            State.NEED -> {
                status.text = "O Shizuku está rodando, mas falta permitir este app."
                grant.visibility = View.VISIBLE
                controls.visibility = View.GONE
            }
            State.READY -> {
                status.text = "Pronto. Escolha uma proporção."
                grant.visibility = View.GONE
                controls.visibility = View.VISIBLE
                readCurrent()
            }
        }
    }

    private fun askPermission() {
        try {
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                toast("Permissão negada. Libere este app dentro do Shizuku.")
            } else {
                Shizuku.requestPermission(1001)
            }
        } catch (e: Throwable) {
            toast("Não consegui pedir a permissão: ${e.message}")
        }
    }

    // ---------------------------------------------------------------- ações

    private fun readCurrent() {
        sh("wm size") { code, out ->
            current.text = if (code == 0) out else "Não consegui ler a tela atual: $out"
            Regex("Physical size: (\\d+)x(\\d+)").find(out)?.let {
                val a = it.groupValues[1].toInt()
                val b = it.groupValues[2].toInt()
                physW = minOf(a, b)
                physH = maxOf(a, b)
                buildPresets()
            }
        }
    }

    private fun applySize(w: Int, h: Int) {
        sh("wm size ${w}x$h") { code, out ->
            if (code == 0) {
                startConfirm()
                readCurrent()
            } else {
                toast("Falhou: $out")
            }
        }
    }

    private fun applyCustom() {
        val w = inputW.text.toString().toIntOrNull()
        val h = inputH.text.toString().toIntOrNull()
        if (w == null || h == null || w !in 320..2160 || h !in 480..4000) {
            toast("Use largura entre 320 e 2160 e altura entre 480 e 4000.")
            return
        }
        applySize(w, h)
    }

    private fun reset() {
        sh("wm size reset") { _, _ ->
            timer?.cancel()
            confirmBox.visibility = View.GONE
            readCurrent()
        }
    }

    private fun startConfirm() {
        timer?.cancel()
        confirmBox.visibility = View.VISIBLE
        timer = object : CountDownTimer(15000, 1000) {
            override fun onTick(ms: Long) {
                confirmText.text = "Manter essa tela? Voltando ao normal em ${ms / 1000 + 1}s"
            }

            override fun onFinish() {
                reset()
            }
        }.start()
    }

    private fun keep() {
        timer?.cancel()
        confirmBox.visibility = View.GONE
        toast("Tela mantida. Agora é só abrir o jogo.")
    }

    // ---------------------------------------------------------------- shell via Shizuku

    private fun sh(cmd: String, done: (Int, String) -> Unit) {
        Thread {
            val r = try {
                runShell(cmd)
            } catch (e: Throwable) {
                -1 to (e.message ?: e.toString())
            }
            runOnUiThread { done(r.first, r.second) }
        }.start()
    }

    // Shizuku.newProcess é privado nas versões novas da API; reflexão é o jeito comum de chamá-lo.
    private fun runShell(cmd: String): Pair<Int, String> {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", "$cmd 2>&1"), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        val code = p.waitFor()
        return code to out.trim()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
